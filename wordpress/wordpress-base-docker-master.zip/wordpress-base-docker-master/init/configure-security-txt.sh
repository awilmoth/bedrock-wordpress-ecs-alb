#!/bin/sh

# create publicly accessible security.txt file
curl -s https://raw.githubusercontent.com/ministryofjustice/security-guidance/master/contact/vulnerability-disclosure-security.txt -o /tmp/security.txt
mkdir /bedrock/web/.well-known
mv /tmp/security.txt /bedrock/web/.well-known/security.txt
