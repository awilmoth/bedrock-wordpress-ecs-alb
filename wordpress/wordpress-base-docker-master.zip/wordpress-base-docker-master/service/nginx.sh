#!/bin/sh
exec /usr/sbin/nginx